/*
 *  Licensed to the Apache Software Foundation (ASF) under one
 *  or more contributor license agreements.  See the NOTICE file
 *  distributed with this work for additional information
 *  regarding copyright ownership.  The ASF licenses this file
 *  to you under the Apache License, Version 2.0 (the
 *  "License"); you may not use this file except in compliance
 *  with the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing,
 *  software distributed under the License is distributed on an
 *  "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 *  KIND, either express or implied.  See the License for the
 *  specific language governing permissions and limitations
 *  under the License.
 */
package groovy.cli;

import java.io.Serial;
import java.util.HashMap;

/**
 * Map-backed command-line option metadata with a typed default value.
 *
 * @param <T> the option value type
 */
public class TypedOption<T> extends HashMap<String, T> {
    @Serial private static final long serialVersionUID = 8931624081859777854L;

    /**
     * Returns the configured default value.
     *
     * @return the default value, if any
     */
    public T defaultValue() {
        return (T) super.get("defaultValue");
    }
}
