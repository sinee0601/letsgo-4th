/*
 *  Licensed to the Apache Software Foundation (ASF) under one
 *  or more contributor license agreements.  See the NOTICE file
 *  distributed with this work for additional information
 *  regarding copyright ownership.  The ASF licenses this file
 *  to you under the Apache License, Version 2.0 (the
 *  "License"); you may not use this file except in compliance
 *  with the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing,
 *  software distributed under the License is distributed on an
 *  "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 *  KIND, either express or implied.  See the License for the
 *  specific language governing permissions and limitations
 *  under the License.
 */
package groovy.transform;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Marks a method within an {@link ActiveObject} class for
 * actor-backed execution.
 * <p>
 * When {@code blocking = true} (the default), the caller blocks
 * until the actor processes the method and returns the result.
 * When {@code blocking = false}, the method returns an
 * {@link groovy.concurrent.Awaitable} immediately.
 *
 * @see ActiveObject
 * @since 6.0.0
 */
@Retention(RetentionPolicy.SOURCE)
@Target(ElementType.METHOD)
public @interface ActiveMethod {

    /**
     * If {@code true} (default), the caller blocks until the method
     * completes. If {@code false}, an {@code Awaitable} is returned.
     */
    boolean blocking() default true;
}
