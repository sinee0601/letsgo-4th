/*
 *  Licensed to the Apache Software Foundation (ASF) under one
 *  or more contributor license agreements.  See the NOTICE file
 *  distributed with this work for additional information
 *  regarding copyright ownership.  The ASF licenses this file
 *  to you under the Apache License, Version 2.0 (the
 *  "License"); you may not use this file except in compliance
 *  with the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing,
 *  software distributed under the License is distributed on an
 *  "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 *  KIND, either express or implied.  See the License for the
 *  specific language governing permissions and limitations
 *  under the License.
 */
package org.codehaus.groovy.tools.groovydoc;

import org.codehaus.groovy.groovydoc.GroovyTag;

/**
 * Stores info about GroovyDoc tags.
 */
public class SimpleGroovyTag implements GroovyTag {
    private final String name;
    private final String param;
    private final String text;

    /**
     * Creates a stored tag representation.
     *
     * @param name the tag name
     * @param param the optional tag parameter
     * @param text the tag body text
     */
    public SimpleGroovyTag(String name, String param, String text) {
        this.name = name;
        this.param = param;
        this.text = text;
    }

    /** {@inheritDoc} */
    @Override
    public String name() {
        return name;
    }

    /** {@inheritDoc} */
    @Override
    public String param() {
        return param;
    }

    /** {@inheritDoc} */
    @Override
    public String text() {
        return text;
    }
}
