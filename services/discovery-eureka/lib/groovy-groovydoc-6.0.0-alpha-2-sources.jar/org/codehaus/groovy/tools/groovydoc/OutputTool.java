/*
 *  Licensed to the Apache Software Foundation (ASF) under one
 *  or more contributor license agreements.  See the NOTICE file
 *  distributed with this work for additional information
 *  regarding copyright ownership.  The ASF licenses this file
 *  to you under the Apache License, Version 2.0 (the
 *  "License"); you may not use this file except in compliance
 *  with the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing,
 *  software distributed under the License is distributed on an
 *  "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 *  KIND, either express or implied.  See the License for the
 *  specific language governing permissions and limitations
 *  under the License.
 */
package org.codehaus.groovy.tools.groovydoc;

/**
 * Receives rendered documentation output and supporting resource copies.
 */
public interface OutputTool {
    /**
     * Ensures that the supplied output location exists.
     *
     * @param filename the output directory or root path to prepare
     */
    void makeOutputArea(String filename);
    /**
     * Writes rendered text to the supplied output file.
     *
     * @param fileName the file to write
     * @param text the rendered content
     * @param charset the character set to use when writing
     * @throws Exception if the output cannot be written
     */
    void writeToOutput(String fileName, String text, String charset) throws Exception;

    /**
     * Copy a resource file (doc-files/, snippet-files/ content) from
     * {@code srcPath} to {@code dstPath}. Routed through the tool rather
     * than calling {@code Files.copy} directly so that alternative tools
     * (notably {@link MockOutputTool}) can intercept the side-effect.
     *
     * @since 6.0.0
     */
    void copyResource(String srcPath, String dstPath) throws Exception;
}
