/*
 *  Licensed to the Apache Software Foundation (ASF) under one
 *  or more contributor license agreements.  See the NOTICE file
 *  distributed with this work for additional information
 *  regarding copyright ownership.  The ASF licenses this file
 *  to you under the Apache License, Version 2.0 (the
 *  "License"); you may not use this file except in compliance
 *  with the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing,
 *  software distributed under the License is distributed on an
 *  "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 *  KIND, either express or implied.  See the License for the
 *  specific language governing permissions and limitations
 *  under the License.
 */
package groovy.console.ui;

import groovy.lang.GroovyShell;

import javax.swing.JTextPane;
import javax.swing.text.Style;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyleContext;
import javax.swing.text.StyledDocument;
import java.awt.Color;

/**
 * Base support class for consoles that evaluate Groovy scripts and render styled output.
 */
public abstract class ConsoleSupport {

    /** Style used for prompts. */
    Style promptStyle;
    /** Style used for entered commands. */
    Style commandStyle;
    /** Style used for evaluated output. */
    Style outputStyle;
    private GroovyShell shell;
    /** Counter used to create unique script names. */
    int counter;

    /**
     * Initializes the styles used by the output document.
     *
     * @param outputArea text pane whose styled document should be configured
     */
    protected void addStylesToDocument(JTextPane outputArea) {
        StyledDocument doc = outputArea.getStyledDocument();

        Style def = StyleContext.getDefaultStyleContext().getStyle(StyleContext.DEFAULT_STYLE);

        Style regular = doc.addStyle("regular", def);
        StyleConstants.setFontFamily(def, "Monospaced");

        promptStyle = doc.addStyle("prompt", regular);
        StyleConstants.setForeground(promptStyle, Color.BLUE);

        commandStyle = doc.addStyle("command", regular);
        StyleConstants.setForeground(commandStyle, Color.MAGENTA);

        outputStyle = doc.addStyle("output", regular);
        StyleConstants.setBold(outputStyle, true);
    }

    /**
     * Returns the style used for entered commands.
     *
     * @return the command style
     */
    public Style getCommandStyle() {
        return commandStyle;
    }

    /**
     * Returns the style used for evaluated output.
     *
     * @return the output style
     */
    public Style getOutputStyle() {
        return outputStyle;
    }

    /**
     * Returns the style used for prompts.
     *
     * @return the prompt style
     */
    public Style getPromptStyle() {
        return promptStyle;
    }

    /**
     * Returns the shell used for script evaluation.
     *
     * @return the lazily created shell
     */
    public GroovyShell getShell() {
        if (shell == null) {
            shell = new GroovyShell();
        }
        return shell;
    }

    /**
     * Evaluates the supplied text and delegates failures to {@link #handleException(String, Exception)}.
     *
     * @param text script text to evaluate
     * @return the evaluation result, or {@code null} when evaluation fails
     */
    protected Object evaluate(String text) {
        String name = "Script" + counter++;
        try {
            return getShell().evaluate(text, name);
        } catch (Exception e) {
            handleException(text, e);
            return null;
        }
    }

    /**
     * Handles an exception raised while evaluating the supplied script text.
     *
     * @param text script text being evaluated
     * @param e exception raised during evaluation
     */
    protected abstract void handleException(String text, Exception e);
}
