/*
 *  Licensed to the Apache Software Foundation (ASF) under one
 *  or more contributor license agreements.  See the NOTICE file
 *  distributed with this work for additional information
 *  regarding copyright ownership.  The ASF licenses this file
 *  to you under the Apache License, Version 2.0 (the
 *  "License"); you may not use this file except in compliance
 *  with the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing,
 *  software distributed under the License is distributed on an
 *  "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 *  KIND, either express or implied.  See the License for the
 *  specific language governing permissions and limitations
 *  under the License.
 */
package org.apache.groovy.ginq.provider.collection.runtime

import groovy.transform.AutoFinal
import groovy.transform.CompileStatic
import groovy.transform.PackageScope
import groovy.transform.stc.POJO

import static groovy.transform.PackageScopeTarget.*

/**
 * Immutable named list to represent list result of GINQ
 *
 * @since 4.0.0
 */
@PackageScope([CLASS, CONSTRUCTORS, METHODS])
@CompileStatic
@AutoFinal
@POJO
class NamedTuple<E> extends Tuple<E> {

    private static final long serialVersionUID = -5067092453136522209L

    private final Map<String, E> data

    /**
     * Creates an immutable tuple backed by the supplied names.
     *
     * @param elementList the element values
     * @param nameList the names matching those values
     */
    NamedTuple(List<E> elementList, List<String> nameList) {
        super(elementList as E[])

        final int nameListSize = nameList.size()
        final int elementListSize = elementList.size()

        if (nameListSize != elementListSize) {
            throw new IllegalArgumentException("elements(size: $elementListSize) and names(size: $nameListSize) should have the same size")
        }
        if (nameListSize != new HashSet<>(nameList).size()) {
            throw new IllegalArgumentException("names should be unique: $nameList")
        }

        data = new LinkedHashMap<>((int) (nameListSize / 0.75) + 1)

        for (int i = 0; i < nameListSize; i += 1) {
            data.put(nameList.get(i), elementList.get(i))
        }
    }

    /**
     * Returns the value bound to the supplied name.
     *
     * @param name the tuple element name
     * @return the bound value
     */
    public get(String name) {
        return data.get(name)
    }

    /**
     * Returns the value bound to the supplied name.
     *
     * @param name the tuple element name
     * @return the bound value
     */
    public getAt(String name) {
        return data.get(name)
    }

    /**
     * Tests whether this tuple contains the supplied name.
     *
     * @param name the tuple element name
     * @return {@code true} if the name exists
     */
    boolean exists(String name) {
        return data.containsKey(name)
    }

    /**
     * Returns the tuple element names in order.
     *
     * @return the tuple element names
     */
    List<String> getNameList() {
        return new ArrayList<>(data.keySet())
    }

    /**
     * Returns the tuple contents in {@code name:value} form.
     *
     * @return the tuple string form
     */
    @Override
    public String toString() {
        StringJoiner sj = new StringJoiner(', ', '(', ')')
        for (String name : getNameList()) {
            sj.add(name + ':' + this[name])
        }
        return sj.toString()
    }
}
