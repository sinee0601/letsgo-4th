/*
 *  Licensed to the Apache Software Foundation (ASF) under one
 *  or more contributor license agreements.  See the NOTICE file
 *  distributed with this work for additional information
 *  regarding copyright ownership.  The ASF licenses this file
 *  to you under the Apache License, Version 2.0 (the
 *  "License"); you may not use this file except in compliance
 *  with the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing,
 *  software distributed under the License is distributed on an
 *  "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 *  KIND, either express or implied.  See the License for the
 *  specific language governing permissions and limitations
 *  under the License.
 */
package groovy.text;

import java.io.Serial;

/**
 * A custom exception class to flag template execution errors
 */
public class TemplateExecutionException extends Exception  {
    @Serial private static final long serialVersionUID = 3940987189684210921L;
    private final int lineNumber;

    /**
     * Creates an exception for an execution failure at the supplied template line.
     *
     * @param lineNumber one-based line number in the template source
     */
    public TemplateExecutionException(int lineNumber) {
        super();
        this.lineNumber = lineNumber;
    }

    /**
     * Creates an exception for an execution failure at the supplied template line.
     *
     * @param lineNumber one-based line number in the template source
     * @param message a description of the execution failure
     */
    public TemplateExecutionException(int lineNumber, String message) {
        super(message);
        this.lineNumber = lineNumber;
    }

    /**
     * Creates an exception for an execution failure at the supplied template line.
     *
     * @param lineNumber one-based line number in the template source
     * @param message a description of the execution failure
     * @param cause the underlying execution failure
     */
    public TemplateExecutionException(int lineNumber, String message, Throwable cause) {
        super(message, cause);
        this.lineNumber = lineNumber;
    }

    /**
     * Creates an exception for an execution failure at the supplied template line.
     *
     * @param lineNumber one-based line number in the template source
     * @param cause the underlying execution failure
     */
    public TemplateExecutionException(int lineNumber, Throwable cause) {
        super(cause);
        this.lineNumber = lineNumber;
    }

    /**
     * Returns the line number in the template source where the error occurred
     *
     * @return the one-based line number of the template execution error
     */
    public int getLineNumber() {
        return lineNumber;
    }
}
